n = int(input())
while n > 0:
    s = input()
    if "it" in s:
        print("YES")
    else:
        print("NO")
    n = n - 1

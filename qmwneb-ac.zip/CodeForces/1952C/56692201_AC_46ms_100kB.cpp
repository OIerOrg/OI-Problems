#include <bits/stdc++.h>
int main() {
    std::vector<int> ans = { 10, 10, 8, 9, 8, 7, 7, 7, 7, 0, 9, 6, 8 };
    int x;
    std::cin >> x;
    std::cout << ans[x];
    return 0;
}
a = input()
while a != '42':
    print (a)
    a = input()